<?php
// Provera da li je forma poslata
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prikupljanje podataka iz forme
    $name = filter_var($_POST["name"], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $message = filter_var($_POST["message"], FILTER_SANITIZE_STRING);
    $recipient = filter_var($_POST["recipient"], FILTER_SANITIZE_EMAIL);
    
    // Validacija podataka
    if (empty($name) || empty($email) || empty($message)) {
        echo "Molimo popunite sva polja.";
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Molimo unesite ispravnu email adresu.";
        exit;
    }
    
    // Podešavanje email-a
    $to = $recipient;
    $subject = "Nova poruka sa sajta Lavanda";
    
    // Kreiranje email sadržaja
    $email_content = "Ime: $name\n";
    $email_content .= "Email: $email\n\n";
    $email_content .= "Poruka:\n$message\n";
    
    // Podešavanje email zaglavlja
    $headers = "From: $name <$email>\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    
    // Slanje email-a
    if (mail($to, $subject, $email_content, $headers)) {
        // Uspešno poslat email
        header("Location: index.html?status=success#kontakt");
        exit;
    } else {
        // Greška pri slanju email-a
        header("Location: index.html?status=error#kontakt");
        exit;
    }
} else {
    // Ako neko pokuša da direktno pristupi ovoj stranici
    header("Location: index.html");
    exit;
}
?>